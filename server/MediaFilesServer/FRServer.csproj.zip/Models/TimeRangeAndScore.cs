﻿
namespace FRServer.Models
{
    class TimeRangeAndScore
    {
        public string From { get; set; }
        public string To { get; set; }
        public int Score { get; set; }
        public string VideoName { get; set; }
    }
}
