﻿namespace FRServer.Models
{
    public class FaceDetectRequest
    {
        public string VideoFileName { get; set; }
        //public string FacesFolder { get; set; }
    }
}
