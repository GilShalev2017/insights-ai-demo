﻿namespace FRServer.Models
{
    class SubjectDetailsAndRange
    {
        public string Name { get; set; }
        public string From { get; set; }
        public string To { get; set; }
        public int Score { get; set; }
    }
}
